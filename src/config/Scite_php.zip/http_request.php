<?
print ("*** PHP Executor for SciTE (c)2002 Bernd Kreuss ***\n");
flush();

$filename=str_replace('\\','/',$argv[1]); //replace backslashes
$filesystempath=str_replace('\\','/',$argv[2]); //replace backslashes
$httppath=$argv[3];
$interpreter=$argv[4];

$newpath=str_replace($filesystempath,$httppath,$filename);

if (substr($newpath,0,7)!='http://'){
    if (preg_match('/\.php(\d)*$/i',$newpath)){
        print("--- Script is not in webserver folder '$filesystempath'. Will execute it directly\n");
        print("--- Executing '$newpath' with '$interpreter' and output to 'c:\\temp\\temp.html'\n");
        flush();
        exec($interpreter.' -f '.$newpath.' > c:\temp\temp.html');
        
        print("--- Starting Browser with 'c:\\temp\\temp.html'\n");
        flush();
        exec('start c:\temp\temp.html > nul');
        
    }else{
        $url='file://'.$newpath;
        print("--- File is not in webserver folder '$filesystempath'. Will open it directly with the browser\n");
        print("--- Starting Browser with '$newpath'\n");
        flush();
        exec('start '.$url.' > nul');
    }
}else{
    print("--- File is inside '$filesystempath' which is also reachable via '$httppath'. Will request it via HTTP\n");
    $url=$newpath;
    print("--- Requesting $url with Browser\n");
    flush();
    exec('start '.$url.' > nul');
}
?>